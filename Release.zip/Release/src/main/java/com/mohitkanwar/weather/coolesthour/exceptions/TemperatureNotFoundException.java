package com.mohitkanwar.weather.coolesthour.exceptions;

public class TemperatureNotFoundException extends RuntimeException {


    public TemperatureNotFoundException(String message) {
        super(message);
    }

}
