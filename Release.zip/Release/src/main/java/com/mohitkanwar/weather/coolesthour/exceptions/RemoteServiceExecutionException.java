package com.mohitkanwar.weather.coolesthour.exceptions;

public class RemoteServiceExecutionException extends RuntimeException {


    public RemoteServiceExecutionException(String message) {
        super(message);
    }

}
