package com.mohitkanwar.weather.coolesthour.exceptions;

public class USZipCodeNotFound extends RuntimeException {


    public USZipCodeNotFound(String message) {
        super(message);
    }

}
