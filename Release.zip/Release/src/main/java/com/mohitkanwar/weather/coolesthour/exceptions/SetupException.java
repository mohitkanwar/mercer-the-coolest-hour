package com.mohitkanwar.weather.coolesthour.exceptions;

public class SetupException extends RuntimeException {


    public SetupException(String message) {
        super(message);
    }


}
