package com.mohitkanwar.weather.coolesthour.integrations.response.model;

public class Country {
    private String ID;


    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }


}
